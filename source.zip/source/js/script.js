import "./menu-open.js";
import updateSlider from "./promo-slider.js";
import "./slider.js";

updateSlider();
